function passou()
{
    var passa = document.getElementById("buttonmouseover");
    passa.style.backgroundColor = "#eb4034";
    var passatext = document.getElementById("textomouseover");
    passatext.innerText = "Passou";
}
function escrevendo(x){
        x.style.background = "yellow";
}
function seletor(){
    var x = document.getElementById("seletor").value;
    document.getElementById("demo").innerHTML = "selecionou: " + x;
}