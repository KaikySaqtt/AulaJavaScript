
function apertou()
{
    var byid = document.getElementById("nomes");
    var byclassname = document.getElementsByClassName("nome");
    var byname = document.getElementsByName("nome");
    var querySelector = document.querySelector(".nome");
    var querySelectorAll = document.querySelectorAll("input.nome");
    var res = document.getElementById("res");
    var res1 = document.getElementById("res1");
    var res2 = document.getElementById("res2");
    var res3 = document.getElementById("res3");
    var res4 = document.getElementById("res4");
    res.innerHTML = byid.value;
    res1.innerHTML = byclassname[0].value;
    res2.innerHTML = byname[0].value;
    res3.innerHTML = querySelector.value;
    res4.innerHTML = querySelectorAll[0].value;
}