function alta(){
    var cb = document.getElementById("caixabaixa").value;
    document.getElementById("demo").innerHTML = cb.toUpperCase();
}

