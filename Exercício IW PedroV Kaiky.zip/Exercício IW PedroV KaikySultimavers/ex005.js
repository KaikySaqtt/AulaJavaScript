function ale()
{
    alert("apertou");
}
function retorna(){
    function returna(x, y){
        return x/y;
    }
    var resultado = returna(5,2);
    console.log(resultado);
}

var modelo = document.getElementById("seletormodelo").value;
var cor = document.getElementById("seletorcor").value;
function CorModelo()
{
    var modelo = document.getElementById("seletormodelo").value;
    var cor = document.getElementById("seletorcor").value;
    dcument.getElementById("demo").innerHTML = "Seu carro é um " + modelo + " com cor " + cor;
}

function chamasoma(){
    var soma = function(a, b) {
        return a + b;
    };
    var resultado = soma(3, 5);
    console.log(resultado);
}
function chamasub(){
    var num1 = document.getElementById("num1").value;
    var num2 = document.getElementById("num2").value;
    const subtracao = (a, b) => a - b;
    console.log(subtracao(num1, num2))
}

