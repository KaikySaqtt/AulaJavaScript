function soma(){
    var num1 = parseFloat(document.getElementById("num1").value);
    var num2 = parseFloat(document.getElementById("num2").value);
    const somaa = (a, b) => a + b;
    const somados = somaa(num1, num2)
    document.getElementById("demo").innerHTML = somados;
}