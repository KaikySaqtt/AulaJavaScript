cont = 0
function conta(){
    cont += 1;
    document.getElementById("demo").innerHTML = cont;
}