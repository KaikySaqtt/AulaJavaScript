function apertou()
{
    alert("Clicou!!")
}